@extends("layouts.app")

@section("title", "Hello")

@section("content")
    <h1>Hello world</h1>
@endsection