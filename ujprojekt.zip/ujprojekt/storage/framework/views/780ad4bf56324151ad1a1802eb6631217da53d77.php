

<?php $__env->startSection("title", "User profile"); ?>

<?php $__env->startSection("content"); ?>
    <h1><?php echo e($user->name); ?></h1>
    <h2><?php echo e($user->email); ?></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\krisa\ujprojekt\resources\views/profile.blade.php ENDPATH**/ ?>